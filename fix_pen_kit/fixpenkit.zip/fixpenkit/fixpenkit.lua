local lastCelData = {} -- 用于存储上一次的 cel 数据

-- 平滑轮廓笔刷核心脚本
local EdgeSmootherCore = dofile("./edge_smoother_core.lua")
-- 清理笔刷核心脚本
local CleanCore = dofile("./clean_core.lua")

---------------------------------------------------------------------------------------
-- 主脚本，用于选择和执行不同的笔刷模式
local FixPenKit = {}
function FixPenKit:Execute(options)

local spr = app.activeSprite
if not spr then app.alert("请先打开一个精灵") return end

-- 提前声明对话框
local dlg

---------------- 更新状态 ----------------------

-- 记录上一次 site 信息，确保在切换cel时及时更新
local lastSite = {
  frame = app.activeFrame and app.activeFrame.frameNumber or nil,
  layer = app.activeLayer and app.activeLayer.stackIndex or nil,
  cel = app.activeCel
}
-- 更新cel
local function updateLast()
  if app.activeCel and app.activeLayer then
    local layerId = app.activeLayer.id
    lastCelData[layerId] = {
      image = app.activeCel.image:clone(),
      position = app.activeCel.position,
      bounds = app.activeCel.bounds
    }
    -- 同步 lastSite
    lastSite.frame = app.activeFrame and app.activeFrame.frameNumber or nil
    lastSite.layer = app.activeLayer and app.activeLayer.stackIndex or nil
    lastSite.cel = app.activeCel
  end
   -- print("更新cel")

end
updateLast()

----------------- 监听 ------------------------
-- 监听sitechange，在帧或图层变化时更新cel
local siteListener = app.events:on('sitechange', function()
  updateLast()
end)

-- 监听撤销和重做命令，在撤销或重做时更新cel
local afterCommandListener = app.events:on('aftercommand', function(ev)
  if ev.name == "Undo" or ev.name == "Redo" then
    updateLast()
  end
end)

-- 监听前景色变化，分别用于更改选区笔颜色和普通绘制颜色
local fgColorListener = nil
local regularFgColorListener = nil

----------------- 参数 ------------------------
-- 记录启动前的工具
local prevTool = app.activeTool

-- 选择笔模式
local isSelectionPencilEnabled = true -- 默认启用

-- 记录当前模式
local currentMode = "Edge Smoother Pen"

-- 鼠标状态跟踪
local isDrawing = false
local lastPixelCount = 0

-- 选择笔颜色，初始为半透明蓝紫色。
local tempFgColor = Color{ r=128, g=0, b=255, a=128 }
-- 普通绘制颜色，初始为当前前景色。
local prevFgColor = app.fgColor

-- Clean Pen 相关变量
local tempLineColor = Color{ r=0, g=255, b=0, a=128 }
local lineColor = tempLineColor
local colorThreshold = 32
local isolationStrictness = 0


---------------- 选区笔处理逻辑 ------------------
-- 根据已构建的选区直接处理并调用核心脚本
local function processSelectionMode(change, sprite, cel, afterSelectionCallback)
  local selectionChanged = false
  if change.leftPressed then
    sprite.selection:add(change.selection)
    selectionChanged = true
  elseif change.rightPressed then
    sprite.selection:subtract(change.selection)
    selectionChanged = true
  end

  -- 恢复像素内容
  local layerId = app.activeLayer and app.activeLayer.id
  local celData = lastCelData[layerId]
  if app.activeCel and celData and celData.image then
    app.activeCel.image = celData.image:clone()
    app.activeCel.position = celData.position
  end

  -- 生成选区后调用核心
  if selectionChanged and afterSelectionCallback then
    afterSelectionCallback()
  end
end

-- 根据颜色判断鼠标按键（左键绘制前景色，右键绘制背景色）
local function GetButtonsPressed(pixels, previous, next)
  if #pixels == 0 then return false, false end

  local pixel = pixels[1]
  local getPixel = next.image.getPixel

  -- 新像素颜色
  local newPixelValue = getPixel(next.image, pixel.x - next.position.x, pixel.y - next.position.y)
  if app.fgColor.rgbaPixel == newPixelValue then
    return true, false
  elseif app.bgColor.rgbaPixel == newPixelValue then
    return false, true
  end
  return true, false -- 默认左键
end

-- 优化选区构建：批量添加矩形而不是逐个添加（超大画布优化版）
local function buildSelectionFromPixels(pixels)
  if #pixels == 0 then
    return Selection()
  end
  
  -- 如果像素数量很少，直接逐个添加
  if #pixels < 50 then
    local selection = Selection()
    for _, pixel in ipairs(pixels) do
      selection:add(Rectangle(pixel.x, pixel.y, 1, 1))
    end
    return selection
  end
  
  -- 超大画布优化：使用更高效的矩形合并算法
  if #pixels > 1000 then
    -- 对于大量像素，使用更激进的合并策略
    local selection = Selection()
    local pixelMap = {}
    
    -- 构建像素映射
    for _, pixel in ipairs(pixels) do
      local key = pixel.x .. "," .. pixel.y
      pixelMap[key] = true
    end
    
    local processed = {}
    
    -- 首先尝试构建较大的矩形区域
    for _, pixel in ipairs(pixels) do
      local key = pixel.x .. "," .. pixel.y
      if not processed[key] then
        -- 尝试构建矩形区域（不仅仅是水平线段）
        local startX, startY = pixel.x, pixel.y
        local maxWidth, maxHeight = 1, 1
        
        -- 寻找最大可能的矩形
        for h = 1, math.min(20, #pixels) do -- 限制高度搜索，避免过度计算
          local currentWidth = 0
          for w = 1, math.min(50, #pixels) do -- 限制宽度搜索
            local testKey = (startX + w - 1) .. "," .. (startY + h - 1)
            if pixelMap[testKey] and not processed[testKey] then
              currentWidth = w
            else
              break
            end
          end
          
          if currentWidth > 0 and h * currentWidth > maxWidth * maxHeight then
            maxWidth, maxHeight = currentWidth, h
          else
            break
          end
        end
        
        -- 标记已处理的像素
        for y = startY, startY + maxHeight - 1 do
          for x = startX, startX + maxWidth - 1 do
            processed[x .. "," .. y] = true
          end
        end
        
        -- 添加矩形到选区
        selection:add(Rectangle(startX, startY, maxWidth, maxHeight))
      end
    end
    
    return selection
  else
    -- 中等数量像素：使用原有的水平线段合并
    local selection = Selection()
    local pixelMap = {}
    
    -- 构建像素映射
    for _, pixel in ipairs(pixels) do
      local key = pixel.x .. "," .. pixel.y
      pixelMap[key] = true
    end
    
    local processed = {}
    
    for _, pixel in ipairs(pixels) do
      local key = pixel.x .. "," .. pixel.y
      if not processed[key] then
        -- 尝试构建水平线段
        local startX = pixel.x
        local endX = pixel.x
        local y = pixel.y
        
        -- 向右扩展
        while pixelMap[(endX + 1) .. "," .. y] and not processed[(endX + 1) .. "," .. y] do
          endX = endX + 1
        end
        
        -- 标记已处理的像素
        for x = startX, endX do
          processed[x .. "," .. y] = true
        end
        
        -- 添加矩形到选区
        selection:add(Rectangle(startX, y, endX - startX + 1, 1))
      end
    end
    
    return selection
  end
end

-- 分析像素变化并构建选区（超大画布优化版）
local function CalculateChangeAndSelection(previous, next)
  if not previous or not previous.image or not next or not next.image then
    return {
      pixels={}, 
      selection=Selection(), 
      leftPressed=false, 
      rightPressed=false, 
      sizeChanged=false
    }
  end
  
  local pixels = {}
  local getPixel = previous.image.getPixel
  local shift = {
    x = next.position.x - previous.position.x,
    y = next.position.y - previous.position.y
  }
  
  -- 超大画布优化：动态采样策略
  local imageArea = next.image.width * next.image.height
  local isLargeCanvas = imageArea > 1000000 -- 1M像素以上认为是大画布
  
  -- 优化1: 计算变化的边界框，只检测可能变化的区域
  local prevBounds = previous.bounds
  local nextBounds = next.bounds
  
  -- 计算需要检查的区域（两个边界框的并集）
  local checkMinX = math.max(0, math.min(prevBounds.x - next.position.x, nextBounds.x - next.position.x))
  local checkMinY = math.max(0, math.min(prevBounds.y - next.position.y, nextBounds.y - next.position.y))
  local checkMaxX = math.min(next.image.width - 1, 
    math.max(prevBounds.x + prevBounds.width - next.position.x, 
             nextBounds.x + nextBounds.width - next.position.x))
  local checkMaxY = math.min(next.image.height - 1,
    math.max(prevBounds.y + prevBounds.height - next.position.y,
             nextBounds.y + nextBounds.height - next.position.y))
  
  -- 超大画布优化：进一步缩小检测区域
  if isLargeCanvas then
    -- 对于超大画布，增加边界缓冲，但限制最大检测区域
    local maxCheckArea = 500000 -- 最大检测50万像素
    local checkArea = (checkMaxX - checkMinX + 1) * (checkMaxY - checkMinY + 1)
    
    if checkArea > maxCheckArea then
      -- 如果检测区域太大，采用中心区域 + 边缘采样的策略
      local centerX = (checkMinX + checkMaxX) / 2
      local centerY = (checkMinY + checkMaxY) / 2
      local maxRadius = math.sqrt(maxCheckArea / math.pi)
      
      checkMinX = math.max(checkMinX, math.floor(centerX - maxRadius))
      checkMaxX = math.min(checkMaxX, math.floor(centerX + maxRadius))
      checkMinY = math.max(checkMinY, math.floor(centerY - maxRadius))
      checkMaxY = math.min(checkMaxY, math.floor(centerY + maxRadius))
    end
  end
  
  -- 如果没有重叠区域，直接返回
  if checkMinX > checkMaxX or checkMinY > checkMaxY then
    -- 对于大画布，采用采样检测而非全遍历
    if isLargeCanvas then
      local step = math.max(1, math.floor(math.sqrt(imageArea) / 100)) -- 动态步长
      for x = 0, next.image.width - 1, step do
        for y = 0, next.image.height - 1, step do
          local nextPixelValue = getPixel(next.image, x, y)
          if Color(nextPixelValue).alpha > 0 then
            -- 检测到变化后，在周围进行精细扫描
            for dx = 0, step - 1 do
              for dy = 0, step - 1 do
                local px, py = x + dx, y + dy
                if px < next.image.width and py < next.image.height then
                  local pv = getPixel(next.image, px, py)
                  if Color(pv).alpha > 0 then
                    local pixelCoord = {x = px + next.position.x, y = py + next.position.y}
                    table.insert(pixels, pixelCoord)
                  end
                end
              end
            end
            break
          end
        end
        if #pixels > 0 then break end
      end
    else
      -- 小画布保持原有逻辑
      for x = 0, next.image.width - 1 do
        for y = 0, next.image.height - 1 do
          local nextPixelValue = getPixel(next.image, x, y)
          if Color(nextPixelValue).alpha > 0 then
            local pixelCoord = {x = x + next.position.x, y = y + next.position.y}
            table.insert(pixels, pixelCoord)
          end
        end
      end
    end
  else
    -- 超大画布优化：分块处理 + 并行化思想
    if isLargeCanvas then
      local blockSize = 64 -- 64x64像素块
      local maxPixelsToCheck = 10000 -- 最多检测1万个像素
      local pixelsChecked = 0
      
      -- 分块遍历，优先检测中心区域
      local centerX = (checkMinX + checkMaxX) / 2
      local centerY = (checkMinY + checkMaxY) / 2
      local blocks = {}
      
      -- 生成按距离中心排序的块列表
      for bx = checkMinX, checkMaxX, blockSize do
        for by = checkMinY, checkMaxY, blockSize do
          local blockCenterX = bx + blockSize / 2
          local blockCenterY = by + blockSize / 2
          local distToCenter = (blockCenterX - centerX)^2 + (blockCenterY - centerY)^2
          table.insert(blocks, {x = bx, y = by, dist = distToCenter})
        end
      end
      
      -- 按距离排序，优先处理中心区域
      table.sort(blocks, function(a, b) return a.dist < b.dist end)
      
      -- 处理优先级最高的几个块
      for _, block in ipairs(blocks) do
        if pixelsChecked >= maxPixelsToCheck then break end
        
        local blockEndX = math.min(block.x + blockSize - 1, checkMaxX)
        local blockEndY = math.min(block.y + blockSize - 1, checkMaxY)
        
        for x = block.x, blockEndX do
          for y = block.y, blockEndY do
            if pixelsChecked >= maxPixelsToCheck then break end
            
            local shiftedX = x + shift.x
            local shiftedY = y + shift.y
            local prevPixelValue = getPixel(previous.image, shiftedX, shiftedY)
            local nextPixelValue = getPixel(next.image, x, y)
            
            if (shiftedX < 0 or shiftedX > previous.image.width - 1 or
                shiftedY < 0 or shiftedY > previous.image.height - 1) then
              if Color(nextPixelValue).alpha > 0 then
                local pixelCoord = {x = x + next.position.x, y = y + next.position.y}
                table.insert(pixels, pixelCoord)
              end
            elseif prevPixelValue ~= nextPixelValue then
              local pixelCoord = {x = x + next.position.x, y = y + next.position.y}
              table.insert(pixels, pixelCoord)
            end
            
            pixelsChecked = pixelsChecked + 1
          end
          if pixelsChecked >= maxPixelsToCheck then break end
        end
      end
    else
      -- 小画布保持原有优化逻辑
      for x = checkMinX, checkMaxX do
        for y = checkMinY, checkMaxY do
          local shiftedX = x + shift.x
          local shiftedY = y + shift.y
          local prevPixelValue = getPixel(previous.image, shiftedX, shiftedY)
          local nextPixelValue = getPixel(next.image, x, y)
          if (shiftedX < 0 or shiftedX > previous.image.width - 1 or
              shiftedY < 0 or shiftedY > previous.image.height - 1) then
            if Color(nextPixelValue).alpha > 0 then
              local pixelCoord = {x = x + next.position.x, y = y + next.position.y}
              table.insert(pixels, pixelCoord)
            end
          elseif prevPixelValue ~= nextPixelValue then
            local pixelCoord = {x = x + next.position.x, y = y + next.position.y}
            table.insert(pixels, pixelCoord)
          end
        end
      end
    end
  end

  -- 使用优化的选区构建
  local newSelection = buildSelectionFromPixels(pixels)
  local leftPressed, rightPressed = GetButtonsPressed(pixels, previous, next)

  return {
    pixels = pixels,
    selection = newSelection,
    leftPressed = leftPressed,
    rightPressed = rightPressed,
    sizeChanged = previous.bounds.width ~= next.bounds.width or
                  previous.bounds.height ~= next.bounds.height
  }
end

-- 清理笔刷模式下的处理逻辑
local function processCleanPenMode(change, sprite, cel)
  processSelectionMode(change, sprite, cel, function()
    CleanCore:Execute{
      colorThreshold = dlg.data.colorThreshold or colorThreshold,
      lineColor = dlg.data.lineColor or lineColor,
      isolationStrictness = dlg.data.isolationStrictness or isolationStrictness
    }
  end)
end

-- 平滑轮廓笔刷模式下的处理逻辑
local function processEdgeSmootherPenMode(change, sprite, cel)
  processSelectionMode(change, sprite, cel, function()
    EdgeSmootherCore:Execute{
      window = dlg.data.window or 9,
      iterations = dlg.data.iterations or 1,
      fillColor = dlg.data.fillColor,
      autoFillColor = dlg.data.autoFillColor
    }
  end)
end


-- 图像发生变化时，调用相应笔刷的处理逻辑
local function onSpriteChange(ev)
  if not app.activeCel then return end
  if app.activeTool.id ~= "pencil" then return end

  local layerId = app.activeLayer and app.activeLayer.id
  local celData = lastCelData[layerId]
  if not celData or not celData.image then return end

  local change = CalculateChangeAndSelection(celData, app.activeCel)
  
  -- 检测鼠标状态变化
  local currentPixelCount = #change.pixels
  local wasDrawing = isDrawing
  
  if currentPixelCount > 0 and not wasDrawing then
    -- 开始绘制
    isDrawing = true
  elseif currentPixelCount == 0 and wasDrawing then
    -- 结束绘制，此时更新 lastCelData
    isDrawing = false
    updateLast()
    return
  end
  
  if #change.pixels == 0 then
    if change.sizeChanged and lastCelData then
      app.activeCel.image = lastCelData.image
      app.activeCel.position = lastCelData.position
    end
    -- 不 updateLast()，保持撤销链
  elseif change.leftPressed or change.rightPressed then
    if currentMode == "Edge Smoother Pen" then
      app.transaction(function()
        local oldFg = app.fgColor
        app.fgColor = tempFgColor
        processEdgeSmootherPenMode(change, spr, celData)
        app.fgColor = oldFg
      end)
      -- 执行完核心脚本后立即更新，以便下次绘制时基于最新状态
      updateLast()
    elseif currentMode == "Clean Pen" then
      app.transaction(function()
        local oldFg = app.fgColor
        app.fgColor = lineColor
        processCleanPenMode(change, spr, celData)
        app.fgColor = oldFg
      end)
      -- 执行完核心脚本后立即更新，以便下次绘制时基于最新状态
      updateLast()
    else
      -- 普通笔刷模式，鼠标松开时会调用 updateLast()
    end
  end
  
  lastPixelCount = currentPixelCount
  app.refresh()
end
local onChangeListener = spr.events:on('change', onSpriteChange)




------------------ 切换模式 --------------------------
local function enableSelectionPencil()
  isSelectionPencilEnabled = true
  app.fgColor = tempFgColor
  -- 注册前景色变化监听
  if not fgColorListener then
    fgColorListener = app.events:on('fgcolorchange', function()
      if isSelectionPencilEnabled then
        tempFgColor = app.fgColor
        -- 同步UI控件
        if dlg then
          dlg:modify{id="selectionColor_edge_smoother", color=tempFgColor}
          dlg:modify{id="selectionColor_clean", color=tempFgColor}
        end
      end
    end)
  end
end

local function disableSelectionPencil()
  isSelectionPencilEnabled = false
  app.fgColor = prevFgColor
  if fgColorListener then
    app.events:off(fgColorListener)
    fgColorListener = nil
  end
  
end




------------------- 生成对话框 ------------------------

dlg = Dialog{
  title = "FixPen Kit",
  onclose = function()
    spr.events:off(onChangeListener)
    if siteListener then app.events:off(siteListener) end
    if prevTool then app.activeTool = prevTool end
    app.fgColor = prevFgColor
    if options and options.onclose then options.onclose() end
  end
}



dlg:tab{
  id = "regurlar",
  text = "Regular Pen",
  onclick = function(ev)
    currentMode = "Regurlar Pen"
    disableSelectionPencil()

    
        -- 注册普通笔前景色监听
    if not regularFgColorListener then
      regularFgColorListener = app.events:on('fgcolorchange', function()
        if currentMode == "Regurlar Pen" then
          prevFgColor = app.fgColor
          -- 同步UI控件
          if dlg then
            dlg:modify{id="regular_color", color=prevFgColor}
          end
        end
      end)
    end
      updateLast()  -- 切换到普通笔刷时同步 cel
    
  end
}
dlg:color{ id="regular_color", label="Regular Color", enabled=true,
   color = prevFgColor,
  onchange = function(ev)
        prevFgColor = ev.color
          app.fgColor = prevFgColor
  end }

dlg:tab{
  id = "smoother",
  text = "Edge Smoother Pen",
  onclick = function(ev)
    currentMode = "Edge Smoother Pen"
    enableSelectionPencil()
          updateLast()  -- 切换到 Smoother 笔刷时同步 cel

  end
}

dlg:color{ id="selectionColor_edge_smoother", label="Selection Color", enabled=true,
   color = tempFgColor,
  onchange = function(ev)
    tempFgColor = ev.color
    if isSelectionPencilEnabled then
      app.fgColor = tempFgColor
    end
  end }
dlg:color{ id="fillColor", label="Fill Color", enabled=true, color = Color{ r=255, g=255, b=255, a=255 } }
dlg:check{ id="autoFillColor", label="Auto Fill Color", enabled=true }
dlg:slider{ id="window", label="window", min=3, max=33, value=9 }
dlg:slider{ id="iterations", label="iterations", min=1, max=20, value=1 }

dlg:tab{
  id = "clean",
  text = "Clean Pen",
  onclick = function(ev)
    currentMode = "Clean Pen"
    enableSelectionPencil()
              updateLast()  -- 切换到 Smoother 笔刷时同步 cel

  end
}
dlg:color{ id="selectionColor_clean", label="Selection Color", enabled=true,
   color = tempFgColor,
  onchange = function(ev)
    tempFgColor = ev.color
    if isSelectionPencilEnabled then
      app.fgColor = tempFgColor
    end
  end }
dlg:color{ id="lineColor", label="Line Color", enabled=true , onchange = function(ev) lineColor = ev.color end}
dlg:slider{ id="colorThreshold", label="Line Color Threshold", min=0, max=255, value=colorThreshold, enabled=true, onchange = function(ev) colorThreshold = ev.value end }
dlg:slider{ id="isolationStrictness", label="Isolation Strictness", min=0, max=4, value=0 }


dlg:endtabs{selected = "smoother"} -- 结束 tabs 分组



dlg:show{wait=false}

-- 默认启用选区笔
enableSelectionPencil()

end

return FixPenKit