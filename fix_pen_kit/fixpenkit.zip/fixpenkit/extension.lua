local FixPenKit = dofile("./fixpenkit.lua")

local isFixPenKitOpen = false

function init(plugin)
    plugin:newCommand{
        id = "FixPenKit",
        title = "FixPen Kit",
        group = "edit_fill",
        onenabled = function()
            return app.activeSprite ~= nil
                and not isFixPenKitOpen
                and app.activeSprite.colorMode ~= ColorMode.INDEXED
        end,
        onclick = function()
            isFixPenKitOpen = true
            FixPenKit:Execute{
                onclose = function() isFixPenKitOpen = false end
            }
            
        end
    }

   
end

function exit(plugin) end
