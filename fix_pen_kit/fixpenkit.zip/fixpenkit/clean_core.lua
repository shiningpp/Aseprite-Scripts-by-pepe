local CleanCore = {}

function CleanCore:Execute(options)



local spr = app.activeSprite
if not spr then app.alert("请先打开一个精灵") return end




local cel = app.activeCel
if not cel then app.alert("请先选择一个Cel") return end

local initialLayer = app.activeLayer

-- 检查是否有选区，没有则直接退出
local selection = spr.selection
if not selection or selection.isEmpty then
  app.alert("请先框选一个区域")
  return
end

-- 获取选区的边界，只处理选区内的图像
local selectionBounds = selection.bounds
local origImg = Image(selectionBounds.width, selectionBounds.height, cel.image.colorMode)
origImg:drawImage(cel.image, Point(-selectionBounds.x + cel.position.x, -selectionBounds.y + cel.position.y))
-- origPos 是选区在画布中的绝对位置，不是相对于 cel 的位置
local origPos = Point(selectionBounds.x, selectionBounds.y)

local frame = app.activeFrame

-- -----------------------------
-- 提取线条（只在选区范围内处理）
-- -----------------------------

  local cleanedLayer = spr:newLayer()


    -- 提取线条的阈值
  local colorThreshold = options and options.colorThreshold or 50
  local targetColor = options and options.lineColor
  local isolationStrictness = options and options.isolationStrictness or 0

  local function colorDistance(c1, c2)
    local dr = math.abs(app.pixelColor.rgbaR(c1) - app.pixelColor.rgbaR(c2))
    local dg = math.abs(app.pixelColor.rgbaG(c1) - app.pixelColor.rgbaG(c2))
    local db = math.abs(app.pixelColor.rgbaB(c1) - app.pixelColor.rgbaB(c2))
    local da = math.abs(app.pixelColor.rgbaA(c1) - app.pixelColor.rgbaA(c2))
    return dr + dg + db + da
  end

  local linePoints = {}
  local lineImg = Image(origImg.width, origImg.height, origImg.colorMode)

  -- 只遍历选区对应的矩形区域，检查每个像素是否真的在选区内
  for y = 0, origImg.height - 1 do
    for x = 0, origImg.width - 1 do
      -- 计算在画布中的绝对坐标
      local canvasX = x + selectionBounds.x
      local canvasY = y + selectionBounds.y
      
      -- 只有真正在选区内的像素才处理
      if selection:contains(canvasX, canvasY) then
        local imgColor = origImg:getPixel(x, y)
        if app.pixelColor.rgbaA(imgColor) > 0 and
           colorDistance(imgColor, targetColor.rgbaPixel) <= colorThreshold then
          table.insert(linePoints, {x = x, y = y})
          lineImg:drawPixel(x, y, imgColor)
        end
      end
    end
  end

  -- 把线条的的所有像素填充为前景色
  for _, pt in ipairs(linePoints) do
    lineImg:drawPixel(pt.x, pt.y, targetColor)
  end

  -- 提取线条后，绘制到新临时图层
  local tempLayer_line = spr:newLayer()
  tempLayer_line.name = "临时线条"
  spr:newCel(tempLayer_line, frame.frameNumber, lineImg, origPos)
  tempLayer_line.isVisible = false


  local function findConnectedRegions(points)
  local pointSet = {}
  for _, pt in ipairs(points) do
    pointSet[pt.x..","..pt.y] = true
  end
  local visited = {}
  local regions = {}

  for _, pt in ipairs(points) do
    local key = pt.x..","..pt.y
    if not visited[key] then
      local region = {}
      local stack = {pt}
      visited[key] = true
      while #stack > 0 do
        local cur = table.remove(stack)
        table.insert(region, cur)
        for dy = -1,1 do for dx = -1,1 do
          if not (dx==0 and dy==0) then
            local nx, ny = cur.x+dx, cur.y+dy
            local nkey = nx..","..ny
            if pointSet[nkey] and not visited[nkey] then
              visited[nkey] = true
              table.insert(stack, {x=nx, y=ny})
            end
          end
        end end
      end
      table.insert(regions, region)
    end
  end
  return regions
end


local function connectRegions(regions, img)
  while #regions > 1 do
    local minDist = math.huge
    local minA, minB, minPa, minPb
    -- 找最近的两个区域
    for i = 1, #regions-1 do
      for j = i+1, #regions do
        for _, pa in ipairs(regions[i]) do
          for _, pb in ipairs(regions[j]) do
            local d = (pa.x-pb.x)^2 + (pa.y-pb.y)^2
            if d < minDist then
              minDist = d
              minA, minB = i, j
              minPa, minPb = pa, pb
            end
          end
        end
      end
    end
    -- 用Bresenham补一条线
    local function bresenham(x0, y0, x1, y1)
      local dx = math.abs(x1 - x0)
      local dy = math.abs(y1 - y0)
      local sx = x0 < x1 and 1 or -1
      local sy = y0 < y1 and 1 or -1
      local err = dx - dy
      while true do
        img:drawPixel(x0, y0, targetColor)
        if x0 == x1 and y0 == y1 then break end
        local e2 = 2 * err
        if e2 > -dy then err = err - dy; x0 = x0 + sx end
        if e2 < dx  then err = err + dx; y0 = y0 + sy end
      end
    end
    bresenham(minPa.x, minPa.y, minPb.x, minPb.y)
    -- 合并区域
    for _, pt in ipairs(regions[minB]) do
      table.insert(regions[minA], pt)
    end
    table.remove(regions, minB)
  end
end


-- 找所有连通区域
local regions = findConnectedRegions(linePoints)

-- 不断补点直到连通
connectRegions(regions, lineImg)


-- 连通后绘制到新临时图层
local tempLayer_line_connect = spr:newLayer()
tempLayer_line_connect.name = "连通线条"
spr:newCel(tempLayer_line_connect, frame.frameNumber, lineImg, origPos)
tempLayer_line_connect.isVisible = false


-- 辅助函数：判断两个点是否是8邻域（即在像素上连通）
local function isConnected(p1, p2)
  local dx = math.abs(p1.x - p2.x)
  local dy = math.abs(p1.y - p2.y)
  return dx <= 1 and dy <= 1
end


-- 判断是否为单像素宽路径
local function isSinglePixelWide(img)
  for y = 0, img.height - 1 do
    for x = 0, img.width - 1 do
      if app.pixelColor.rgbaA(img:getPixel(x, y)) > 0 then
        local count = 0
        for dy = -1,1 do for dx = -1,1 do
          if not (dx==0 and dy==0) then
            local nx, ny = x+dx, y+dy
            if nx >= 0 and nx < img.width and ny >= 0 and ny < img.height then
              if app.pixelColor.rgbaA(img:getPixel(nx, ny)) > 0 then
                count = count + 1
              end
            end
          end
        end end
        if count > 4 then
          return false
        end
      end
    end
  end
  return true
end



-- 去除“Z”字形、多余中间点（像素对角冗余）
local function removeDiagonalZigzag(path)
  if #path < 3 then return path end

  local cleaned = {}
  local lastKept = path[1]
  table.insert(cleaned, lastKept)

  local i = 2
  while i < #path do
    local curr = path[i]
    local next = path[i + 1]

    if not isConnected(lastKept, next) then
      table.insert(cleaned, curr)
      lastKept = curr
    end
    -- 否则 curr 是冗余点，跳过，不更新 lastKept

    i = i + 1
  end

  table.insert(cleaned, path[#path]) -- 最后一个点始终保留
  return cleaned
end

-- 路径排序
local function sortPath(points, img)
  -- 构建点查找表
  local pointSet = {}
  for _, pt in ipairs(points) do
    pointSet[pt.x..","..pt.y] = true
  end

  -- 找端点（邻居为1的点），如果没有端点就随便选一个
  local function neighborCount(x, y)
    local count = 0
    for dy = -1,1 do for dx = -1,1 do
      if not (dx==0 and dy==0) then
        local nx, ny = x+dx, y+dy
        if pointSet[nx..","..ny] then count = count + 1 end
      end
    end end
    return count
  end

  local startPt = nil
  for _, pt in ipairs(points) do
    if neighborCount(pt.x, pt.y) == 1 then
      startPt = pt
      break
    end
  end
  if not startPt then startPt = points[1] end

  -- 路径排序
  local sorted = {}
  local visited = {}
  local cur = startPt
  while cur do
    table.insert(sorted, cur)
    visited[cur.x..","..cur.y] = true
    local nextPt = nil
    for dy = -1,1 do for dx = -1,1 do
      if not (dx==0 and dy==0) then
        local nx, ny = cur.x+dx, cur.y+dy
        local key = nx..","..ny
        if pointSet[key] and not visited[key] then
          nextPt = {x=nx, y=ny}
          break
        end
      end
    end end
    cur = nextPt
  end

  return sorted
end


local tempLayer_line_connect_no_z = spr:newLayer()
-- -- 如果路径是单像素宽的，进行对路径的去除z字形操作
if isSinglePixelWide(lineImg) then
  -- 提取所有点为路径
  local path = {}
  for y = 0, lineImg.height - 1 do
    for x = 0, lineImg.width - 1 do
      if app.pixelColor.rgbaA(lineImg:getPixel(x, y)) > 0 then
        table.insert(path, {x = x, y = y})
      end
    end
  end
  -- 路径排序
  path = sortPath(path, lineImg)
  -- 去Z字形
  local cleaned = removeDiagonalZigzag(path)
  -- 清空并重绘
  lineImg:clear()
  for _, pt in ipairs(cleaned) do
    lineImg:drawPixel(pt.x, pt.y, targetColor)
  end

  tempLayer_line_connect_no_z.name = "去z字形后连通线条"
  spr:newCel(tempLayer_line_connect_no_z, frame.frameNumber, lineImg, origPos)
  tempLayer_line_connect_no_z.isVisible = true

end


-- -----------------------------
-- 清理杂色（只在选区范围内处理）
-- -----------------------------

-- 在清理杂色前，复制一份原图像，用于最终输出
local cleanedImg = origImg:clone()
-- 复制一份原图像，用于参考，但不直接在上面更改，以免影响其他像素点的处理
local cleanedImg_ref = origImg:clone()

-- 在清理杂色前，只绘制去z字形后连通线条中有像素颜色的点到 cleanedImg_ref 上
for y = 0, lineImg.height - 1 do
  for x = 0, lineImg.width - 1 do
    local color = lineImg:getPixel(x, y)
    if app.pixelColor.rgbaA(color) > 0 then
      cleanedImg_ref:drawPixel(x, y, color)
    end
  end
end


-- 清理杂色
local fgColor = targetColor.rgbaPixel

for y = 0, cleanedImg_ref.height - 1 do
  for x = 0, cleanedImg_ref.width - 1 do
    -- 计算在画布中的绝对坐标
    local canvasX = x + selectionBounds.x
    local canvasY = y + selectionBounds.y
    
    -- 只有真正在选区内的像素才处理
    if selection:contains(canvasX, canvasY) then
      local origColor = cleanedImg_ref:getPixel(x, y)
      local cleanedColor = lineImg:getPixel(x, y)
      if app.pixelColor.rgbaA(origColor) > 0 and app.pixelColor.rgbaA(cleanedColor) == 0 then
        
        -- 检查是否为边缘像素（相对于图像边界，不是选区边界）
        local isEdge = (x == 0 or x == cleanedImg_ref.width - 1 or 
                        y == 0 or y == cleanedImg_ref.height - 1)
        if not isEdge then
          -- 检查是否为孤立像素
          local sameColorCount = 0
          local neighborColors = {}
          for dy = -1,1 do for dx = -1,1 do
            if not (dx==0 and dy==0) then
              local nx, ny = x+dx, y+dy
              if nx >= 0 and nx < cleanedImg_ref.width and ny >= 0 and ny < cleanedImg_ref.height then
                local nColor = cleanedImg_ref:getPixel(nx, ny)
                table.insert(neighborColors, nColor)
                if nColor == origColor then
                  sameColorCount = sameColorCount + 1
                end
              end
            end
          end end

          local isIsolated = (sameColorCount <= isolationStrictness)

          if isIsolated and #neighborColors > 0 then
        -- ...existing color replacement logic...
        local colorCount = {}
        for _, c in ipairs(neighborColors) do
          colorCount[c] = (colorCount[c] or 0) + 1
        end

        -- 排除前景色
        colorCount[fgColor] = nil

        -- 找出现最多的颜色之前，先判断邻居中（除了前景色和自身同色）有无与自身很接近的颜色
        local similarColor = nil
        local similarityThreshold = 20

        if sameColorCount == 0 then
          for _, c in ipairs(neighborColors) do
            if c ~= fgColor and c ~= origColor and colorDistance(c, origColor) <= similarityThreshold then
              similarColor = c
              break
            end
          end
        else
          for _, c in ipairs(neighborColors) do
            if c ~= fgColor and c ~= origColor and colorDistance(c, origColor) <= similarityThreshold then
              similarColor = c
              break
            end
          end
        end

        if similarColor then
          cleanedImg:drawPixel(x, y, similarColor)
        else
          local maxCount, maxColor = 0, nil
          for c, n in pairs(colorCount) do
            if c ~= origColor and n > maxCount then
              maxCount = n
              maxColor = c
            end
          end

          if not maxColor then
            colorCount = {}
            for _, c in ipairs(neighborColors) do
              if c ~= origColor then
                colorCount[c] = (colorCount[c] or 0) + 1
              end
            end
            for c, n in pairs(colorCount) do
              if n > maxCount then
                maxCount = n
                maxColor = c
              end
            end
          end

          if maxColor then
            cleanedImg:drawPixel(x, y, maxColor)
          end
        end
        end
        end
      end
    end
  end
end



-- 清理杂色后，绘制到新图层
cleanedLayer.name = "清理杂色后"
spr:newCel(cleanedLayer, frame.frameNumber, cleanedImg, origPos)
cleanedLayer.isVisible = true



-- 获取图层对象
local baseLayer = cel.layer  -- 原图层

-- 将 cleanedLayer 合并到 baseLayer
do
  local baseCel = baseLayer:cel(frame)
  local cleanedCel = cleanedLayer:cel(frame)
  if baseCel and cleanedCel then
    -- 正确计算相对位置：cleanedCel 的位置相对于 baseCel 的位置
    local relativePos = cleanedCel.position - baseCel.position
    baseCel.image:drawImage(cleanedCel.image, relativePos)
  end
  spr:deleteLayer(cleanedLayer)
end

-- 合并后，清除原图层中选区内被处理过但现在应该为透明的像素
do
  local baseCel = baseLayer:cel(frame)
  if baseCel then
    local baseImg = baseCel.image
    -- origPos 是选区在画布中的绝对位置
    -- baseCel.position 是原图层在画布中的位置
    -- 需要计算选区相对于原图层的偏移
    local offset = origPos - baseCel.position
    
    for y = 0, baseImg.height - 1 do
      for x = 0, baseImg.width - 1 do
        local canvasX = x + baseCel.position.x
        local canvasY = y + baseCel.position.y
        if selection:contains(canvasX, canvasY) then
          -- 计算对应在 cleanedImg 中的坐标
          local cx, cy = x - offset.x, y - offset.y
          local inCleaned = cx >= 0 and cy >= 0 and cx < cleanedImg.width and cy < cleanedImg.height
          local cleanedPixel = inCleaned and cleanedImg:getPixel(cx, cy) or app.pixelColor.rgba(0,0,0,0)
          if app.pixelColor.rgbaA(cleanedPixel) == 0 and app.pixelColor.rgbaA(baseImg:getPixel(x, y)) > 0 then
            baseImg:drawPixel(x, y, app.pixelColor.rgba(0,0,0,0))
          end
        end
      end
    end
  end
end

-- 再将 tempLayer_line_connect_no_z 合并到 baseLayer
do
  local baseCel = baseLayer:cel(frame)
  local tempCel = tempLayer_line_connect_no_z:cel(frame)
  if baseCel and tempCel then
    -- 正确计算相对位置
    local relativePos = tempCel.position - baseCel.position
    baseCel.image:drawImage(tempCel.image, relativePos)
  end
  spr:deleteLayer(tempLayer_line_connect_no_z)
end

-- 删除其他临时图层
if tempLayer_line then spr:deleteLayer(tempLayer_line) end
if tempLayer_line_connect then spr:deleteLayer(tempLayer_line_connect) end

-- 选中一开始的图层
if initialLayer then
  app.activeLayer = initialLayer
end

-- 取消选择
if selection and not selection.isEmpty then
  selection:deselect()
else
  app.activeSelection = nil
end







app.refresh()



end

return CleanCore