local EdgeSmootherCore = {}

function EdgeSmootherCore:Execute(options)


local spr = app.activeSprite
local selection = spr.selection
local cel = app.activeCel
local frame = app.activeFrame


-- 获取原图像最外侧颜色：即选区中最大非透明连通区域的最外一圈像素的主色
local function getOuterColor(img, selection, cel)
  local w, h = img.width, img.height
  local visited = {}
  local maxRegion = {}
  local maxRegionSize = 0

  -- 获取cel在画布上的偏移
  local offsetX = cel.position.x
  local offsetY = cel.position.y

  -- Flood fill 寻找所有连通非透明区域，记录最大区域
  -- 遍历画布范围（或选区范围），而不是img范围
  local bounds = selection and selection.bounds or {x=0, y=0, width=w, height=h}
  for y = bounds.y, bounds.y + bounds.height - 1 do
    for x = bounds.x, bounds.x + bounds.width - 1 do
      local imgX = x - offsetX
      local imgY = y - offsetY
      local key = x .. "," .. y
      if not visited[key]
         and (not selection or selection:contains(x, y))
         and imgX >= 0 and imgX < w and imgY >= 0 and imgY < h
         and app.pixelColor.rgbaA(img:getPixel(imgX, imgY)) > 0 then
        local region = {}
        local stack = {{x=x, y=y}}
        visited[key] = true
        while #stack > 0 do
          local p = table.remove(stack)
          table.insert(region, p)
          for dy = -1,1 do for dx = -1,1 do
            if dx ~= 0 or dy ~= 0 then
              local nx, ny = p.x+dx, p.y+dy
              local nkey = nx .. "," .. ny
              local nImgX = nx - offsetX
              local nImgY = ny - offsetY
              if nx >= bounds.x and nx < bounds.x + bounds.width
                 and ny >= bounds.y and ny < bounds.y + bounds.height
                 and not visited[nkey]
                 and (not selection or selection:contains(nx, ny))
                 and nImgX >= 0 and nImgX < w and nImgY >= 0 and nImgY < h
                 and app.pixelColor.rgbaA(img:getPixel(nImgX, nImgY)) > 0 then
                visited[nkey] = true
                table.insert(stack, {x=nx, y=ny})
              end
            end
          end end
        end
        if #region > maxRegionSize then
          maxRegion = region
          maxRegionSize = #region
        end
      end
    end
  end

  -- 找最大区域的边界像素（去重）
  local regionSet = {}
  for _, p in ipairs(maxRegion) do
    regionSet[p.x .. "," .. p.y] = true
  end
  local borderSet = {}
  local borderPixels = {}
  for _, p in ipairs(maxRegion) do
    for dy = -1,1 do for dx = -1,1 do
      if dx ~= 0 or dy ~= 0 then
        local nx, ny = p.x+dx, p.y+dy
        local nkey = nx .. "," .. ny
        if nx < bounds.x or nx >= bounds.x + bounds.width
           or ny < bounds.y or ny >= bounds.y + bounds.height
           or not regionSet[nkey]
           or (selection and not selection:contains(nx, ny)) then
          local key = p.x .. "," .. p.y
          if not borderSet[key] then
            borderSet[key] = true
            table.insert(borderPixels, p)
          end
          break
        end
      end
    end end
  end


  -- 统计边界像素颜色
  local colorCount = {}
  for _, p in ipairs(borderPixels) do
    local imgX = p.x - offsetX
    local imgY = p.y - offsetY
    if imgX >= 0 and imgX < w and imgY >= 0 and imgY < h then
      local c = img:getPixel(imgX, imgY)
      if app.pixelColor.rgbaA(c) > 0 then
        colorCount[c] = (colorCount[c] or 0) + 1
      end
    end
  end
  local maxCount, maxColor = 0, nil
  for c, n in pairs(colorCount) do
    if n > maxCount then maxCount, maxColor = n, c end
  end
  return maxColor or app.pixelColor.rgba(0,0,0,0)
end


-- 选区有透明区域时，以此方式进行平滑处理
function EdgeSmootherCore_Has_Transparent()
local spr = app.activeSprite
if not spr then app.alert("请先打开一个精灵") return end

local cel = app.activeCel
if not cel then app.alert("请先选择一个Cel") return end

local initialLayer = app.activeLayer

-- 检查是否有选区，没有则全选
local selection = spr.selection
if not selection or selection.isEmpty then
  spr.selection:select(Rectangle(0, 0, spr.width, spr.height))
  selection = spr.selection
end
local origImg, origPos
local selectionBounds


if selection and not selection.isEmpty then
  -- 获取选区的边界
  selectionBounds = selection.bounds
  -- 处理选区内的图像
  origImg = Image(selectionBounds.width, selectionBounds.height, cel.image.colorMode)
  origImg:drawImage(cel.image, Point(-selectionBounds.x + cel.position.x, -selectionBounds.y + cel.position.y))

  origPos = cel.position + Point(selectionBounds.x, selectionBounds.y)
else
  -- 如果没有选区，处理整个图层
  origImg = cel.image:clone()
  origPos = cel.position
end

local frame = app.activeFrame


  -- -----------------------------
  -- 提取轮廓
  -- -----------------------------

  local origImg = cel.image
  local origPos = cel.position

  -- 执行描边操作（放入临时图层）
  local tempLayer = spr:newLayer()
  tempLayer.name = "临时轮廓层"
  local tempCel = spr:newCel(tempLayer, frame.frameNumber, origImg:clone(), origPos)

  -- 清除选区外像素
  local img = tempCel.image
  local pos = tempCel.position
  for y = 0, img.height - 1 do
    for x = 0, img.width - 1 do
      -- 转为画布坐标
      local canvasX = x + pos.x
      local canvasY = y + pos.y
      if not selection:contains(Point(canvasX, canvasY)) then
        img:drawPixel(x, y, app.pixelColor.rgba(0,0,0,0))
      end
    end
  end

  app.activeCel = tempCel
  app.command.Outline{
    ui = false,
    place = "outside",
    matrix = "circle",
    color = Color(app.fgColor.red, app.fgColor.green, app.fgColor.blue, 255),
  }

  local outlineImg = tempCel.image
  outlinePos = tempCel.position

  local w, h = outlineImg.width, outlineImg.height

  alignedOrigImg = Image(w, h, outlineImg.colorMode)
  alignedOrigImg:clear()
  local dx = origPos.x - outlinePos.x
  local dy = origPos.y - outlinePos.y
  alignedOrigImg:drawImage(origImg, Point(dx, dy))

  -- 提取轮廓线图像
  local contourImg = Image(w, h, outlineImg.colorMode)
  local fg = app.fgColor
  local opaqueColor = Color(fg.red, fg.green, fg.blue, 255)

  for y = 0, h - 1 do
    for x = 0, w - 1 do
      local a1 = app.pixelColor.rgbaA(outlineImg:getPixel(x, y))
      local a0 = app.pixelColor.rgbaA(alignedOrigImg:getPixel(x, y))

      if a1 > 0 and a0 == 0 then
        contourImg:drawPixel(x, y, opaqueColor)
      end
    end
  end

  -- 新建轮廓层并放入未平滑轮廓图
  local contourLayer = spr:newLayer()
  contourLayer.name = "轮廓线层"
  spr:newCel(contourLayer, frame.frameNumber, contourImg, outlinePos or Point(0, 0))

  -- 隐藏临时轮廓层和轮廓线层
  tempLayer.isVisible = false
  contourLayer.isVisible = false



  -- -----------------------------
  -- 对轮廓中的像素点按路径排序
  -- -----------------------------

  -- 提取原始轮廓像素坐标
  local contourPoints = {}
  for y = 0, h - 1 do
    for x = 0, w - 1 do
      local a = app.pixelColor.rgbaA(contourImg:getPixel(x, y))
      if a > 0 then
        table.insert(contourPoints, {x = x, y = y})
      end
    end
  end

-- 辅助函数：判断是否为路径终点
  local function isEndpoint(x, y, img)
  local count = 0
  for dy = -1, 1 do
    for dx = -1, 1 do
      if not (dx == 0 and dy == 0) then
        local nx, ny = x + dx, y + dy
        if nx >= 0 and ny >= 0 and nx < img.width and ny < img.height then
          local a = app.pixelColor.rgbaA(img:getPixel(nx, ny))
          if a > 0 then count = count + 1 end
        end
      end
    end
  end
  return count == 1
end

-- 找到一个端点作为起点
local startIndex = 1
for i, pt in ipairs(contourPoints) do
  if isEndpoint(pt.x, pt.y, contourImg) then
    startIndex = i
    break
  end
end

-- 将选中的起点移动到第一个位置
if startIndex > 1 then
  local first = contourPoints[startIndex]
  table.remove(contourPoints, startIndex)
  table.insert(contourPoints, 1, first)
end

-- 辅助函数：判断两个点是否是8邻域（即在像素上连通）
local function isConnected(p1, p2)
  local dx = math.abs(p1.x - p2.x)
  local dy = math.abs(p1.y - p2.y)
  return dx <= 1 and dy <= 1
end



-- 1.两次广度优先搜索（BFS），针对开放轮廓。能保证路径连接的是两个真端点。
local function findLongestPath_betweenTrueEndpoints(points, selection, cel)
  -- 构建点查找表
  local pointSet = {}
  for _, pt in ipairs(points) do
    pointSet[pt.x .. "," .. pt.y] = pt
  end

  -- 统计每个点的邻居数
  local neighborCount = {}
  for _, pt in ipairs(points) do
    local count = 0
    for dy = -1,1 do for dx = -1,1 do
      if not (dx==0 and dy==0) then
        local key = (pt.x+dx)..","..(pt.y+dy)
        if pointSet[key] then count = count + 1 end
      end
    end end
    neighborCount[pt.x..","..pt.y] = count
  end

  -- 查找端点（且端点必须在选区边缘）
  local endpoints = {}
  for _, pt in ipairs(points) do
    if neighborCount[pt.x..","..pt.y] == 1 then
      local isEdge = false
      for dy = -1,1 do for dx = -1,1 do
        if not (dx==0 and dy==0) then
          local nx, ny = pt.x+dx, pt.y+dy
          local nCanvasX = nx + cel.position.x 
          local nCanvasY = ny + cel.position.y 
          if not selection:contains(nCanvasX, nCanvasY) then
            isEdge = true
            break
          end
        end
      end end
      if isEdge then
        table.insert(endpoints, pt)
      end
    end
  end

  -- 如果端点数量小于等于1，直接返回 nil
  if #endpoints <= 1 then
    return nil
  end

  -- BFS找两端点间路径
  local function bfsPath(startPt, endPt)
    local queue = {{pt=startPt, path={startPt}}}
    local visited = {}
    visited[startPt.x..","..startPt.y] = true
    while #queue > 0 do
      local cur = table.remove(queue, 1)
      if cur.pt.x == endPt.x and cur.pt.y == endPt.y then
        return cur.path
      end
      for dy = -1,1 do for dx = -1,1 do
        if not (dx==0 and dy==0) then
          local nx, ny = cur.pt.x+dx, cur.pt.y+dy
          local key = nx..","..ny
          if pointSet[key] and not visited[key] then
            visited[key] = true
            local newPath = {}
            for _,p in ipairs(cur.path) do table.insert(newPath, p) end
            table.insert(newPath, {x=nx, y=ny})
            table.insert(queue, {pt={x=nx, y=ny}, path=newPath})
          end
        end
      end end
    end
    return nil
  end

  -- 枚举所有端点对，找最长路径
  local longestPath = {}
  for i = 1, #endpoints do
    for j = i+1, #endpoints do
      local path = bfsPath(endpoints[i], endpoints[j])
      if path and #path > #longestPath then
        longestPath = path
      end
    end
  end

  return longestPath
end

-- 2.针对环形轮廓。只获取主环。
local function findMainLoop(points)
  -- 构建点查找表
  local pointSet = {}
  for _, pt in ipairs(points) do
    pointSet[pt.x .. "," .. pt.y] = pt
  end

  -- 统计邻居数
  local neighborCount = {}
  for _, pt in ipairs(points) do
    local count = 0
    for dy = -1,1 do for dx = -1,1 do
      if not (dx==0 and dy==0) then
        local key = (pt.x+dx)..","..(pt.y+dy)
        if pointSet[key] then count = count + 1 end
      end
    end end
    neighborCount[pt.x..","..pt.y] = count
  end

  -- 优先选择邻居数为2的点作为起点
  local startPt = nil
  for _, pt in ipairs(points) do
    if neighborCount[pt.x..","..pt.y] == 2 then
      startPt = pt
      break
    end
  end
  if not startPt then startPt = points[1] end

  local loopPath = {}
  local visited = {}
  local cur = startPt
  local prevKey = nil

  while true do
    local key = cur.x..","..cur.y
    table.insert(loopPath, cur)
    visited[key] = true

    -- 找下一个未访问邻居，优先邻居数为2的点，排除上一个点
    local nextPt = nil
    local candidates = {}
    for dy = -1,1 do for dx = -1,1 do
      if not (dx==0 and dy==0) then
        local nx, ny = cur.x+dx, cur.y+dy
        local nkey = nx..","..ny
        if pointSet[nkey] and not visited[nkey] and nkey ~= prevKey then
          table.insert(candidates, pointSet[nkey])
        end
      end
    end end

    -- 优先选邻居数为2的点
    for _, pt in ipairs(candidates) do
      if neighborCount[pt.x..","..pt.y] == 2 then
        nextPt = pt
        break
      end
    end
    -- 如果没有邻居数为2的点，才选其它
    if not nextPt and #candidates > 0 then
      nextPt = candidates[1]
    end

    if not nextPt or (nextPt.x == startPt.x and nextPt.y == startPt.y) then
      break
    end

    prevKey = key
    cur = nextPt
  end


  
   if #loopPath > 2 and isConnected(loopPath[1], loopPath[#loopPath]) then
    -- 如果首尾相连，说明是一个环形轮廓
    return loopPath
  else
    return {}
  end


   
end

-- 判断选区内图像是否为环形轮廓。即是否为一个周围为透明区域的非透明像素区域。
local function isIsolatedRegion(img, selection, cel)
  if selection.isEmpty then return false end
  local regionSet = {}
  local nonTransparentCount = 0
  local bounds = selection.bounds
  local offsetX = cel.position.x
  local offsetY = cel.position.y

  -- 收集选区内所有非透明像素
  for y = bounds.y, bounds.y + bounds.height - 1 do
    for x = bounds.x, bounds.x + bounds.width - 1 do
      if selection:contains(x, y) then
        local imgX = x - offsetX
        local imgY = y - offsetY
        if imgX >= 0 and imgX < img.width and imgY >= 0 and imgY < img.height then
          local c = img:getPixel(imgX, imgY)
          if app.pixelColor.rgbaA(c) > 0 then
            regionSet[x..","..y] = true
            nonTransparentCount = nonTransparentCount + 1
          end
        end
      end
    end
  end
  if nonTransparentCount == 0 then return false end

  -- 检查选区边界是否有非透明像素
  for key, _ in pairs(regionSet) do
    local x, y = key:match("([^,]+),([^,]+)")
    x, y = tonumber(x), tonumber(y)
    for dy = -1,1 do for dx = -1,1 do
      if not (dx==0 and dy==0) then
        local nx, ny = x+dx, y+dy
        if not selection:contains(nx, ny) then
          -- 只要有一个非透明像素在选区边界，直接返回false
          return false
        end
      end
    end end
  end

  -- Flood fill判断是否为单一连通区域
  local function floodFillAny()
    local visited = {}
    local count = 0
    local sx, sy
    for key, _ in pairs(regionSet) do
      sx, sy = key:match("([^,]+),([^,]+)")
      sx, sy = tonumber(sx), tonumber(sy)
      break
    end
    if not sx then return false end
    local stack = {{x=sx, y=sy}}
    visited[sx..","..sy] = true
    count = 1
    while #stack > 0 do
      local p = table.remove(stack)
      for dy = -1,1 do for dx = -1,1 do
        if not (dx==0 and dy==0) then
          local nx, ny = p.x+dx, p.y+dy
          local nkey = nx..","..ny
          if regionSet[nkey] and not visited[nkey] then
            visited[nkey] = true
            table.insert(stack, {x=nx, y=ny})
            count = count + 1
          end
        end
      end end
    end
    return count == nonTransparentCount
  end

  return floodFillAny()
end


-- 获取排序后的最长路径
local path 


if isIsolatedRegion(origImg, selection,cel) then
  -- app.alert("环形轮廓")
  path = findMainLoop(contourPoints)
else
  path = findLongestPath_betweenTrueEndpoints(contourPoints, selection, tempCel)
end

  if not path or #path == 0 then
    -- 取消操作
    if smoothedLayer then spr:deleteLayer(smoothedLayer) end
    if contourLayer then spr:deleteLayer(contourLayer) end
    if tempLayer then spr:deleteLayer(tempLayer) end
    if fillLayer then spr:deleteLayer(fillLayer) end
    if resultLayer then spr:deleteLayer(resultLayer) end
    if initialLayer then
      app.activeLayer = initialLayer
    end
    selection:deselect()
    return
  end


-- -----------------------------
-- 平滑轮廓
-- -----------------------------


-- 计算角度差函数（用于判断转角）
local function angleBetween(p1, p2, p3)
  local function dot(ax, ay, bx, by)
    return ax * bx + ay * by
  end
  local function length(ax, ay)
    return math.sqrt(ax * ax + ay * ay)
  end

  local v1x, v1y = p1.x - p2.x, p1.y - p2.y
  local v2x, v2y = p3.x - p2.x, p3.y - p2.y
  local cosTheta = dot(v1x, v1y, v2x, v2y) / (length(v1x, v1y) * length(v2x, v2y) + 1e-5)
  return math.acos(math.max(-1, math.min(1, cosTheta))) -- 返回弧度
end

-- 根据角度判断当前点是否是“拐角”，动态决定窗口大小
local function calcDynamicWindow(path, i, minWin, maxWin)
  if i <= 2 or i >= #path - 1 then return minWin end
  local angle = angleBetween(path[i - 1], path[i], path[i + 1])
  local deg = math.deg(angle)

  -- 拐角越明显，窗口越小；角度越接近180度，窗口越大
  local ratio = math.abs(deg - 180) / 180
  local window = minWin + math.floor((1 - ratio) * (maxWin - minWin) + 0.5)
  if window % 2 == 0 then window = window + 1 end -- 确保奇数
  return window
end

-- 加权滑动平均 + 动态窗口
local function weightedSmoothPath(path, minWindow, maxWindow)
  local smoothed = {}
  local n = #path

  for i = 1, n do
    local window = calcDynamicWindow(path, i, minWindow, maxWindow)
    local half = math.floor(window / 2)

    if i <= half or i > n - half then
      smoothed[i] = {x = path[i].x, y = path[i].y}
    else
      -- 权重（三角型）
      local weights = {}
      local sumWeight = 0
      for j = -half, half do
        local w = half + 1 - math.abs(j)
        weights[#weights + 1] = w
        sumWeight = sumWeight + w
      end

      local sumX, sumY = 0, 0
      for j = -half, half do
        local p = path[i + j]
        local w = weights[j + half + 1]
        sumX = sumX + p.x * w
        sumY = sumY + p.y * w
      end

      smoothed[i] = {
        x = math.floor(sumX / sumWeight + 0.5),
        y = math.floor(sumY / sumWeight + 0.5)
      }
    end
  end

  return smoothed
end

-- 双向平滑包装函数
local function bidirectionalWeightedSmoothPath(path, minWindow, maxWindow)
  local n = #path

  -- 正向平滑
  local forward = weightedSmoothPath(path, minWindow, maxWindow)

  -- 反向平滑：先反转路径
  local reversed = {}
  for i = n, 1, -1 do
    reversed[#reversed + 1] = path[i]
  end
  local backwardReversed = weightedSmoothPath(reversed, minWindow, maxWindow)

  -- 再反转回来
  local backward = {}
  for i = #backwardReversed, 1, -1 do
    backward[#backward + 1] = backwardReversed[i]
  end

  -- 合并两个方向的结果
  local result = {}
  for i = 1, n do
    result[i] = {
      x = math.floor((forward[i].x + backward[i].x) / 2 + 0.5),
      y = math.floor((forward[i].y + backward[i].y) / 2 + 0.5)
    }
  end

  return result
end





-- 去除连续重复点
local function removeDuplicatePoints(path)
  local unique = {}
  local prev = nil
  for i, pt in ipairs(path) do
    if not prev or pt.x ~= prev.x or pt.y ~= prev.y then
      table.insert(unique, pt)
      prev = pt
    end
  end
  return unique
end

-- 将平滑后的浮点路径重建为像素路径，避免多余点和断点
local function rebuildPixelPathBresenham(path)
  local result = {}
  local visited = {}

  local function addPixel(x, y)
    local key = x .. "," .. y
    if not visited[key] then
      table.insert(result, {x = x, y = y})
      visited[key] = true
    end
  end

  local function bresenhamLine(x0, y0, x1, y1)
    local dx = math.abs(x1 - x0)
    local dy = math.abs(y1 - y0)
    local sx = x0 < x1 and 1 or -1
    local sy = y0 < y1 and 1 or -1
    local err = dx - dy

    while true do
      addPixel(x0, y0)
      if x0 == x1 and y0 == y1 then break end
      local e2 = 2 * err
      if e2 > -dy then err = err - dy; x0 = x0 + sx end
      if e2 < dx  then err = err + dx; y0 = y0 + sy end
    end
  end

  for i = 1, #path - 1 do
    local x0 = math.floor(path[i].x + 0.5)
    local y0 = math.floor(path[i].y + 0.5)
    local x1 = math.floor(path[i + 1].x + 0.5)
    local y1 = math.floor(path[i + 1].y + 0.5)
    bresenhamLine(x0, y0, x1, y1)
  end

  return result
end

-- 去除“Z”字形、多余中间点（像素对角冗余）
local function removeDiagonalZigzag(path)
  if #path < 3 then return path end

  local cleaned = {}
  local lastKept = path[1]
  table.insert(cleaned, lastKept)

  local i = 2
  while i < #path do
    local curr = path[i]
    local next = path[i + 1]

    if not isConnected(lastKept, next) then
      table.insert(cleaned, curr)
      lastKept = curr
    end
    -- 否则 curr 是冗余点，跳过，不更新 lastKept

    i = i + 1
  end

  table.insert(cleaned, path[#path]) -- 最后一个点始终保留
  return cleaned
end




local smoothedPath = path

-- 创建新图层用来绘制平滑轮廓线
local smoothedImg = Image(w, h, outlineImg.colorMode)
local smoothedLayer = spr:newLayer()
smoothedLayer.name = "平滑轮廓线"



-- 获取反相颜色
local function invertColor(color)
  local r = 255 - app.pixelColor.rgbaR(color)
  local g = 255 - app.pixelColor.rgbaG(color)
  local b = 255 - app.pixelColor.rgbaB(color)
  local a = app.pixelColor.rgbaA(color)
  return app.pixelColor.rgba(r, g, b, a)
end

local outerColor = getOuterColor(origImg,selection,cel)
local invertedOuterColor = invertColor(outerColor)

-- 包装函数：绘制平滑轮廓线
local function previewSmoothedPath(window, iterations)
  -- 重新平滑
  smoothedPath = path
  for i = 1, iterations do

   -- 加权滑动平均 + 动态窗口 + 双向平滑
   smoothedPath = bidirectionalWeightedSmoothPath(smoothedPath, 3,window)

  end
  -- 去除连续重复点
  smoothedPath = removeDuplicatePoints(smoothedPath)
  -- 将平滑后的浮点路径重建为像素路径，避免多余点和断点
  smoothedPath = rebuildPixelPathBresenham(smoothedPath)
  -- 去除“Z”字形、多余中间点（像素对角冗余）
  smoothedPath = removeDiagonalZigzag(smoothedPath)

  -- 清空并绘制到 smoothedImg
  smoothedImg:clear()
  for _, pt in ipairs(smoothedPath) do
    smoothedImg:drawPixel(pt.x, pt.y, invertedOuterColor)
  end
  
  spr:newCel(smoothedLayer, frame.frameNumber, smoothedImg, outlinePos)
  smoothedLayer.isVisible = true
  app.refresh()
end



-- 根据传进的window和iteration来执行
local window = options and options.window or 9
local iterations = options and options.iterations or 1

previewSmoothedPath(window, iterations)


-- -----------------------------
-- 根据平滑后的轮廓调整填充内容
-- -----------------------------
-- 1、生成平滑轮廓线的掩码
local maskImg = Image(w, h, ColorMode.GRAY)
maskImg:clear()
for _, pt in ipairs(smoothedPath) do
  maskImg:drawPixel(pt.x, pt.y, 255)
end

-- 2、用填充获得轮廓线包围的内部区域
-- 新建临时填充层
local fillLayer = spr:newLayer()
fillLayer.name = "临时填充层"
-- local fillImg = Image(w, h, ColorMode.RGB)
local fillW, fillH = selection and selection.bounds.width or w, selection and selection.bounds.height or h
local fillImg = Image(fillW, fillH, ColorMode.RGB)

-- 强制逐像素清空
for y = 0, fillImg.height-1 do
  for x = 0, fillImg.width-1 do
    fillImg:drawPixel(x, y, Color(0,0,0,0))
  end
end

-- 先把轮廓线画到 fillImg 上（用黑色）
for _, pt in ipairs(smoothedPath) do
  -- fillImg:drawPixel(pt.x, pt.y, Color(0,0,0,255))
    -- pt.x, pt.y 是全局坐标
  local fx = pt.x + outlinePos.x - selection.bounds.x
local fy = pt.y + outlinePos.y - selection.bounds.y
  if fx >= 0 and fx < fillW and fy >= 0 and fy < fillH then
    fillImg:drawPixel(fx, fy, Color(0,0,0,255))
  end
end

spr:newCel(fillLayer, frame.frameNumber, fillImg, outlinePos)
app.activeLayer = fillLayer

-- 找到选区内第一个不在轮廓线上的点（全局坐标）
  local fillX, fillY
  local found = false
  if selection and not selection.isEmpty then
    local bounds = selection.bounds
    for y = bounds.y, bounds.y + bounds.height - 1 do
      for x = bounds.x, bounds.x + bounds.width - 1 do
        if selection:contains(Point(x, y)) then
          local fx = x - selection.bounds.x
          local fy = y - selection.bounds.y
          local px = fillImg:getPixel(fx, fy)
          local a = app.pixelColor.rgbaA(px)
          if px ~= Color(0,0,0,255) and a == 0 then
            fillX, fillY = x, y
            found = true
            break
          end
        end
      end
      if found then break end
    end
  else
    fillX, fillY = 0, 0
  end

-- 用自定义4方向flood fill算法填充
if fillX and fillY then
  local visited = {}
  local function key(x, y) return x .. "," .. y end
  local localFillX = fillX - selection.bounds.x
  local localFillY = fillY - selection.bounds.y

  local stack = {{localFillX, localFillY}}
  local fillCount = 0
  while #stack > 0 do
    local p = table.remove(stack)
    local x, y = p[1], p[2]
    if x >= 0 and x < fillImg.width and y >= 0 and y < fillImg.height and not visited[key(x, y)] then
      -- 还原为全局坐标判断选区
      local globalX = x + selection.bounds.x
      local globalY = y + selection.bounds.y
      local px = fillImg:getPixel(x, y)
      local a = app.pixelColor.rgbaA(px)
      if (not selection or selection.isEmpty or selection:contains(Point(globalX, globalY)))
         and px ~= Color(0,0,0,255)
         and px ~= Color(255,0,0,255)
         and a == 0
      then
        fillImg:drawPixel(x, y, Color(255,0,0,255)) -- 填充红色
        fillCount = fillCount + 1
        visited[key(x, y)] = true
        table.insert(stack, {x+1, y})
        table.insert(stack, {x-1, y})
        table.insert(stack, {x, y+1})
        table.insert(stack, {x, y-1})
      end
    end
  end
  -- app.alert("实际填充红色像素数: " .. fillCount)
  spr:newCel(fillLayer, frame.frameNumber, fillImg, Point(selection.bounds.x, selection.bounds.y))
end

-- 生成轮廓线内部mask（未被flood fill且未在轮廓线上的区域，即透明区域即为内部）
local insideMask = Image(fillW, fillH, ColorMode.GRAY)
for y = 0, fillH-1 do
  for x = 0, fillW-1 do
    if fillImg:getPixel(x, y) == 0 then
      insideMask:drawPixel(x, y, 255)
    end
  end
end


-- 统计重合度
local overlapContent, overlapTransparent = 0, 0
for y = 0, fillH-1 do
  for x = 0, fillW-1 do
    if insideMask:getPixel(x, y) == 255 then
      -- 转为全局坐标
      local gx, gy = x + selection.bounds.x, y + selection.bounds.y
      if selection:contains(Point(gx, gy)) then
        -- 原图像对应像素
        local origX = gx - origPos.x
        local origY = gy - origPos.y
        if origX >= 0 and origX < origImg.width and origY >= 0 and origY < origImg.height then
          local c = origImg:getPixel(origX, origY)
          if app.pixelColor.rgbaA(c) > 0 then
            overlapContent = overlapContent + 1
          else
            overlapTransparent = overlapTransparent + 1
          end
        end
      end
    end
  end
end

-- 打印重合度
--print("overlapContent:", overlapContent, "overlapTransparent:", overlapTransparent)

-- 如果重合度低于透明度，说明mask反了，需要反转
if overlapContent < overlapTransparent then
  for y = 0, fillH-1 do
    for x = 0, fillW-1 do
      if insideMask:getPixel(x, y) == 255 then
        insideMask:drawPixel(x, y, 0)
      else
        insideMask:drawPixel(x, y, 255)
      end
    end
  end
  -- 反转后：将轮廓线点加入外侧区域（即insideMask==0），并从内侧区域（insideMask==255）移除
  for _, pt in ipairs(smoothedPath) do
    local maskX = pt.x + outlinePos.x - selection.bounds.x
    local maskY = pt.y + outlinePos.y - selection.bounds.y
    if maskX >= 0 and maskX < fillW and maskY >= 0 and maskY < fillH then
      insideMask:drawPixel(maskX, maskY, 0)
    end
  end
end




-- 3、生成最终图像
local outW, outH, outX, outY
if selection and not selection.isEmpty then
  outW, outH = selection.bounds.width, selection.bounds.height
  outX, outY = selection.bounds.x, selection.bounds.y
else
  outW, outH = w, h
  outX, outY = 0, 0
end

local finalImg = Image(outW, outH, outlineImg.colorMode)
finalImg:clear()

for y = 0, outH-1 do
  for x = 0, outW-1 do
    local gx, gy = x + outX, y + outY
    if selection:contains(Point(gx, gy)) then
      local mx, my = x + outX - outlinePos.x, y + outY - outlinePos.y
      if mx >= 0 and mx < w and my >= 0 and my < h then
        if insideMask:getPixel(x, y) > 0 then
          if alignedOrigImg:getPixel(mx, my) == 0 then
            

            local fillColor = options and options.fillColor or Color{ r=255, g=255, b=255, a=255 }
            local autoFillColor = (options and options.autoFillColor) or false

            local useColor
            if autoFillColor then
              useColor = outerColor
            else
              useColor = fillColor
            end

            finalImg:drawPixel(x, y, useColor)
          else
            finalImg:drawPixel(x, y, alignedOrigImg:getPixel(mx, my))
          end
        else
          finalImg:drawPixel(x, y, app.pixelColor.rgba(0,0,0,0))
        end
      else
        finalImg:drawPixel(x, y, app.pixelColor.rgba(0,0,0,0))
      end
    else
      finalImg:drawPixel(x, y, app.pixelColor.rgba(0,0,0,0))
    end
  end
end

-- 新建图层
local resultLayer = spr:newLayer()
resultLayer.name = "平滑轮廓原图"
spr:newCel(resultLayer, frame.frameNumber, finalImg, Point(outX, outY))



-- 清除原图层选区中的内容
local origCel = cel
local origImage = origCel.image:clone()
local origPos = origCel.position
local bounds = selection.bounds

for y = bounds.y, bounds.y + bounds.height - 1 do
  for x = bounds.x, bounds.x + bounds.width - 1 do
    if selection:contains(Point(x, y)) then
      local cx = x - origPos.x
      local cy = y - origPos.y
      if cx >= 0 and cx < origImage.width and cy >= 0 and cy < origImage.height then
        origImage:drawPixel(cx, cy, app.pixelColor.rgba(0,0,0,0))
      end
    end
  end
end

origCel.image = origImage

-- 合并“平滑轮廓原图”到原图层
local origCel = cel
local origImage = origCel.image:clone()
local origPos = origCel.position

-- 找到 resultLayer 的 cel
local resultCel = resultLayer:cel(frame)
if resultCel then
  local resultImg = resultCel.image
  local resultPos = resultCel.position
  -- 将 resultImg 合并到 origImage
  for y = 0, resultImg.height-1 do
    for x = 0, resultImg.width-1 do
      local color = resultImg:getPixel(x, y) 
      local a = app.pixelColor.rgbaA(color)
      if a > 0 then
        -- 计算在原图中的坐标
        local ox = x + resultPos.x - origPos.x
        local oy = y + resultPos.y - origPos.y
        local gx = ox + origPos.x
        local gy = oy + origPos.y
        if ox >= 0 and ox < origImage.width and oy >= 0 and oy < origImage.height
         and selection:contains(Point(gx, gy)) then
          origImage:drawPixel(ox, oy, color)
        end
      end
    end
  end
  origCel.image = origImage
  -- 隐藏 resultLayer
  resultLayer.isVisible = false
end


-- 隐藏“平滑轮廓线”和“临时填充层”
smoothedLayer.isVisible = false
fillLayer.isVisible = false



-- -----------------------------
-- 删除所有过程图层
-- -----------------------------
if smoothedLayer then spr:deleteLayer(smoothedLayer) end
if contourLayer then spr:deleteLayer(contourLayer) end
if tempLayer then spr:deleteLayer(tempLayer) end
if fillLayer then spr:deleteLayer(fillLayer) end
if resultLayer then spr:deleteLayer(resultLayer) end

-- 选中一开始的图层
if initialLayer then
  app.activeLayer = initialLayer
end




app.refresh()

end

-- 判断是否有透明像素，若无重叠区域也视为有透明像素
local hasTransparent = false
local overlapFound = false
for y = selection.bounds.y, selection.bounds.y + selection.bounds.height - 1 do
  for x = selection.bounds.x, selection.bounds.x + selection.bounds.width - 1 do
    if selection:contains(Point(x, y)) then
      local cx = x - cel.position.x
      local cy = y - cel.position.y
      if cx >= 0 and cy >= 0 and cx < cel.image.width and cy < cel.image.height then
        overlapFound = true
        local c = cel.image:getPixel(cx, cy)
        if app.pixelColor.rgbaA(c) == 0 then
          hasTransparent = true
          break
        end
      end
    end
  end
  if hasTransparent then break end
end
if not overlapFound then
  hasTransparent = true
end

--如果有透明像素，正常处理
if hasTransparent then
  EdgeSmootherCore_Has_Transparent()

--如果没有透明像素
else 
  

--统计选区内所有颜色，进行聚类
local colorMap = {}
for y = selection.bounds.y, selection.bounds.y + selection.bounds.height - 1 do
  for x = selection.bounds.x, selection.bounds.x + selection.bounds.width - 1 do
    if selection:contains(Point(x, y)) then
      local cx = x - cel.position.x
      local cy = y - cel.position.y
      if cx >= 0 and cy >= 0 and cx < cel.image.width and cy < cel.image.height then
        local c = cel.image:getPixel(cx, cy)
        colorMap[c] = (colorMap[c] or 0) + 1
      end
    end
  end
end
local colorList = {}
for c, _ in pairs(colorMap) do table.insert(colorList, c) end

local function colorDistance(c1, c2)
  local dr = math.abs(app.pixelColor.rgbaR(c1) - app.pixelColor.rgbaR(c2))
  local dg = math.abs(app.pixelColor.rgbaG(c1) - app.pixelColor.rgbaG(c2))
  local db = math.abs(app.pixelColor.rgbaB(c1) - app.pixelColor.rgbaB(c2))
  return dr + dg + db
end

-- 初始化
local colorGroup = {}
for _, c in ipairs(colorList) do
  colorGroup[c] = c
end

-- 聚类时合并分组
while #colorList > 2 do
  local minDist, minI, minJ = math.huge, 1, 2
  for i = 1, #colorList-1 do
    for j = i+1, #colorList do
      local d = colorDistance(colorList[i], colorList[j])
      if d < minDist then
        minDist, minI, minJ = d, i, j
      end
    end
  end
  -- 合并minJ到minI
  for k, v in pairs(colorGroup) do
    if v == colorList[minJ] then
      colorGroup[k] = colorList[minI]
    end
  end
  colorMap[colorList[minI]] = (colorMap[colorList[minI]] or 0) + (colorMap[colorList[minJ]] or 0)
  table.remove(colorList, minJ)
end
local groupA, groupB = colorList[1], colorList[2]

if colorMap[groupA]and colorMap[groupB] then
-- 选像素数较少的那组为regionGroup
local regionGroup = colorMap[groupA] < colorMap[groupB] and groupA or groupB

local img2 = Image(cel.image.width, cel.image.height, cel.image.colorMode)
img2:clear()
for y = 0, cel.image.height - 1 do
  for x = 0, cel.image.width - 1 do
    local gx, gy = x + cel.position.x, y + cel.position.y
    if selection:contains(Point(gx, gy)) then
      local c = cel.image:getPixel(x, y)
      if colorGroup[c] == regionGroup then
        img2:drawPixel(x, y, c)
        cel.image:drawPixel(x, y, app.pixelColor.rgba(0,0,0,0))
      end
    end
  end
end



--复制该区域到新图层2，并从原图层清除
local layer1 = app.activeLayer
local layer2 = spr:newLayer()
layer2.name = "区域2"
spr:newCel(layer2, frame.frameNumber, img2, cel.position)


--对layer2做正常处理
app.activeLayer = layer2
EdgeSmootherCore_Has_Transparent()

--对layer1，填充透明区域
app.activeLayer = layer1
cel = app.activeCel
local origImg = Image(selection.bounds.width, selection.bounds.height, cel.image.colorMode)
origImg:drawImage(cel.image, Point(-selection.bounds.x + cel.position.x, -selection.bounds.y + cel.position.y))

local outerColor = getOuterColor(cel.image, selection, cel)

for y = selection.bounds.y, selection.bounds.y + selection.bounds.height - 1 do
    for x = selection.bounds.x, selection.bounds.x + selection.bounds.width - 1 do
      if selection:contains(Point(x, y)) then
        local cx = x - cel.position.x
        local cy = y - cel.position.y
        if cx >= 0 and cy >= 0 and cx < cel.image.width and cy < cel.image.height then
          local c = cel.image:getPixel(cx, cy)
          if app.pixelColor.rgbaA(c) == 0 then
            cel.image:drawPixel(cx, cy, outerColor)
          end
        end
      end
    end
end


-- 将layer2的非透明像素绘制到layer1上，然后删除layer2
local cel2 = layer2:cel(frame)
if cel2 then
  local img2 = cel2.image
  local pos2 = cel2.position
  for y = 0, img2.height - 1 do
    for x = 0, img2.width - 1 do
      local c = img2:getPixel(x, y)
      if app.pixelColor.rgbaA(c) > 0 then
        local lx = x + pos2.x - cel.position.x
        local ly = y + pos2.y - cel.position.y
        if lx >= 0 and lx < cel.image.width and ly >= 0 and ly < cel.image.height then
          cel.image:drawPixel(lx, ly, c)
        end
      end
    end
  end
end
spr:deleteLayer(layer2)



end

app.refresh()


end





-- 取消选择
if selection and not selection.isEmpty then
  selection:deselect()
else
  app.activeSelection = nil
end


end

return EdgeSmootherCore